# Inventory Management System

A production-ready, full-stack Inventory Management System.

| Layer | Stack |
|---|---|
| Frontend | React 18 + Vite 5 + Tailwind CSS 3 |
| Backend | Node.js 20 + Express 4 |
| Database | PostgreSQL on [Neon](https://neon.tech) (serverless) |
| Auth | [Better Auth](https://www.better-auth.com) (email + password, cookie sessions) |
| Hosting | Frontend → Vercel · Backend → Render (Docker) · Image → Docker Hub |
| CI/CD | GitHub Actions |

### Live links

| | |
|---|---|
| Frontend | `https://inventory-management.vercel.app` |
| Backend API | `https://inventory-management-api.onrender.com` |
| Health check | `https://inventory-management-api.onrender.com/api/health` |
| Docker Hub | `https://hub.docker.com/r/<your-dockerhub-username>/inventory-management-backend` |
| Repository | `https://github.com/<your-github-username>/inventory-management-system` |

> Replace the placeholders above with your actual usernames once deployed — see **[DEPLOYMENT.md](./DEPLOYMENT.md)** for the exact steps to get there.

---

## Features

- Email/password authentication (sign up, sign in, sign out, persistent sessions) via Better Auth
- Product CRUD: SKU, name, description, category, quantity, unit price, reorder level
- Category management
- Dashboard with total SKUs, total inventory value, and a live reorder list
- Search/filter inventory by name, SKU, or category
- Low-stock detection endpoint (`quantity <= reorder_level`)
- `/api/health` endpoint reporting service + database status (used by Docker, Render, and uptime checks)

---

## Project structure

```
inventory-management-system/
├── backend/
│   ├── src/
│   │   ├── config/
│   │   │   ├── db.js              # Neon PostgreSQL connection pool
│   │   │   └── auth.js            # Better Auth configuration
│   │   ├── controllers/
│   │   │   ├── product.controller.js
│   │   │   └── category.controller.js
│   │   ├── routes/
│   │   │   ├── health.routes.js   # GET /api/health
│   │   │   ├── product.routes.js
│   │   │   └── category.routes.js
│   │   ├── middleware/
│   │   │   ├── auth.middleware.js # session verification
│   │   │   └── error.middleware.js
│   │   ├── db/
│   │   │   ├── schema.sql         # Better Auth + app tables
│   │   │   └── migrate.js         # applies schema.sql
│   │   └── app.js                 # Express app (middleware + routes)
│   ├── server.js                  # entry point
│   ├── package.json
│   ├── Dockerfile
│   ├── .dockerignore
│   ├── .env.example
│   └── .gitignore
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx
│   │   │   ├── ProtectedRoute.jsx
│   │   │   ├── ProductForm.jsx
│   │   │   └── StockBar.jsx
│   │   ├── pages/
│   │   │   ├── Login.jsx
│   │   │   ├── Register.jsx
│   │   │   ├── Dashboard.jsx
│   │   │   └── Inventory.jsx
│   │   ├── lib/
│   │   │   ├── api.js             # fetch wrapper for backend API
│   │   │   └── auth-client.js     # Better Auth React client
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── Dockerfile                 # used by docker-compose, not by Vercel
│   ├── nginx.conf
│   ├── vercel.json
│   ├── .dockerignore
│   ├── .env.example
│   └── .gitignore
├── docker-compose.yml              # local full-stack dev
├── render.yaml                     # Render Blueprint (backend)
├── .github/workflows/deploy.yml    # CI/CD pipeline
├── DEPLOYMENT.md                   # full deployment walkthrough
├── README.md
└── .gitignore
```

---

## Local development (Windows PowerShell)

### Prerequisites
- Node.js 20+ and npm
- Docker Desktop (optional, for containerized local runs)
- A free [Neon](https://neon.tech) project (or local Postgres — see `docker-compose.yml`)

### 1. Clone and install

```powershell
git clone https://github.com/<your-github-username>/inventory-management-system.git
cd inventory-management-system

cd backend
npm install
cd ..\frontend
npm install
cd ..
```

### 2. Configure environment variables

```powershell
Copy-Item backend\.env.example backend\.env
Copy-Item frontend\.env.example frontend\.env
```

Edit `backend\.env` and set `DATABASE_URL` to your Neon connection string, and generate a `BETTER_AUTH_SECRET`:

```powershell
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

Copy the output into `BETTER_AUTH_SECRET` in `backend\.env`.

### 3. Apply the database schema

```powershell
cd backend
npm run db:migrate
cd ..
```

### 4. Run both apps

```powershell
# Terminal 1
cd backend
npm run dev

# Terminal 2
cd frontend
npm run dev
```

- Backend: http://localhost:4000
- Frontend: http://localhost:5173
- Health check: http://localhost:4000/api/health

### Or, run everything with Docker Compose

```powershell
docker compose up --build
```

- Frontend (served by nginx): http://localhost:5173
- Backend: http://localhost:4000

---

## API reference

All `/api/products` and `/api/categories` routes require an authenticated session (cookie set by Better Auth on sign-in).

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Service + database health check (public) |
| POST | `/api/auth/sign-up/email` | Create account |
| POST | `/api/auth/sign-in/email` | Sign in |
| POST | `/api/auth/sign-out` | Sign out |
| GET | `/api/auth/get-session` | Current session |
| GET | `/api/products` | List products (`?search=`, `?category_id=`) |
| GET | `/api/products/:id` | Get one product |
| POST | `/api/products` | Create product |
| PUT | `/api/products/:id` | Update product |
| DELETE | `/api/products/:id` | Delete product |
| GET | `/api/products/low-stock` | Products at/below reorder level |
| GET | `/api/categories` | List categories |
| POST | `/api/categories` | Create category |
| DELETE | `/api/categories/:id` | Delete category |

---

## Deployment

This repo deploys as three pieces:

1. **Backend** → Docker image built from `backend/Dockerfile`, pushed to **Docker Hub**, deployed on **Render** as a Docker web service.
2. **Frontend** → built by **Vercel** directly from `frontend/`.
3. **Database** → **Neon** serverless PostgreSQL, used by the backend via `DATABASE_URL`.

A GitHub Actions workflow (`.github/workflows/deploy.yml`) automates: backend image build & push → Docker Hub → trigger Render redeploy, and frontend build → deploy to Vercel, on every push to `main`.

**For the complete, exact, copy-pasteable deployment walkthrough (PowerShell commands, dashboard steps, environment variables, troubleshooting, and the final submission checklist), see [DEPLOYMENT.md](./DEPLOYMENT.md).**

---

## Tech notes

- Better Auth's handler is mounted before `express.json()` in `backend/src/app.js` — it parses its own request body, so mounting JSON parsing first will break sign-up/sign-in.
- `pool` (a raw `pg.Pool`) is passed directly to `betterAuth({ database: pool })`; Better Auth detects the Postgres driver and generates Postgres-flavoured SQL.
- Neon requires TLS — the connection pool sets `ssl: { rejectUnauthorized: false }`.
- The frontend Dockerfile/nginx config is used by `docker-compose.yml` for local full-stack testing and as an alternative container deployment path; **Vercel does not use it** — Vercel builds straight from the Vite project.
