/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#11151C",
          soft: "#1B212C",
        },
        paper: "#F6F5F2",
        slate: {
          mid: "#5B6472",
        },
        teal: {
          DEFAULT: "#0E7C7B",
          dark: "#0A5E5D",
          light: "#E4F3F2",
        },
        amber: {
          DEFAULT: "#E8A33D",
          light: "#FBEED9",
        },
        signal: {
          red: "#D64545",
          redLight: "#FBE5E5",
        },
        line: "#E4E2DC",
        haze: "#F1EFEA",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
