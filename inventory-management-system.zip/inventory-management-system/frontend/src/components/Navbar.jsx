import { Link, useNavigate } from "react-router-dom";
import { useSession, signOut } from "../lib/auth-client";

export default function Navbar() {
  const { data: session } = useSession();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate("/login");
  };

  return (
    <header className="border-b border-ink/[0.08] bg-ink">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded bg-teal font-display text-sm font-bold text-white">
            S
          </span>
          <span className="font-display text-lg font-semibold tracking-tight text-white">
            Stockroom
          </span>
        </Link>

        {session?.user && (
          <nav className="flex items-center gap-6 text-sm">
            <Link to="/" className="text-white/70 transition-colors hover:text-white">
              Dashboard
            </Link>
            <Link to="/inventory" className="text-white/70 transition-colors hover:text-white">
              Inventory
            </Link>
            <span className="hidden text-white/40 sm:inline">{session.user.email}</span>
            <button
              onClick={handleSignOut}
              className="rounded-md border border-white/15 px-3 py-1.5 text-white/80 transition-colors hover:bg-white/10 hover:text-white"
            >
              Sign out
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}
