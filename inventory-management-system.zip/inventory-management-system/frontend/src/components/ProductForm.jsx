import { useState, useEffect } from "react";

const empty = {
  sku: "",
  name: "",
  description: "",
  category_id: "",
  quantity: 0,
  unit_price: 0,
  reorder_level: 5,
};

export default function ProductForm({ categories, initial, onSubmit, onClose }) {
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (initial) {
      setForm({
        sku: initial.sku || "",
        name: initial.name || "",
        description: initial.description || "",
        category_id: initial.category_id || "",
        quantity: initial.quantity ?? 0,
        unit_price: initial.unit_price ?? 0,
        reorder_level: initial.reorder_level ?? 5,
      });
    }
  }, [initial]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      await onSubmit({
        ...form,
        category_id: form.category_id || null,
        quantity: Number(form.quantity),
        unit_price: Number(form.unit_price),
        reorder_level: Number(form.reorder_level),
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/50 p-4">
      <div className="card w-full max-w-md p-6">
        <h2 className="font-display text-lg font-semibold text-ink">
          {initial ? "Edit product" : "Add product"}
        </h2>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-mid">SKU</label>
              <input name="sku" value={form.sku} onChange={handleChange} required className="input-field mt-1 font-mono" />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-mid">Name</label>
              <input name="name" value={form.name} onChange={handleChange} required className="input-field mt-1" />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-mid">Description</label>
            <textarea name="description" value={form.description} onChange={handleChange} rows={2} className="input-field mt-1" />
          </div>

          <div>
            <label className="text-xs font-medium text-slate-mid">Category</label>
            <select name="category_id" value={form.category_id} onChange={handleChange} className="input-field mt-1">
              <option value="">Uncategorized</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-mid">Quantity</label>
              <input type="number" min="0" name="quantity" value={form.quantity} onChange={handleChange} className="input-field mt-1" />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-mid">Unit price</label>
              <input type="number" min="0" step="0.01" name="unit_price" value={form.unit_price} onChange={handleChange} className="input-field mt-1" />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-mid">Reorder at</label>
              <input type="number" min="0" name="reorder_level" value={form.reorder_level} onChange={handleChange} className="input-field mt-1" />
            </div>
          </div>

          {error && <p className="text-sm text-signal-red">{error}</p>}

          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
            <button type="submit" disabled={saving} className="btn-primary">
              {saving ? "Saving..." : initial ? "Save changes" : "Add product"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
