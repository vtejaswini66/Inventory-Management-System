/**
 * StockBar — the signature element of the app. A compact horizontal bar
 * that encodes how close a product's quantity is to its reorder threshold,
 * so stock health is scannable at a glance across a dense table.
 */
export default function StockBar({ quantity, reorderLevel }) {
  const ratio = reorderLevel > 0 ? quantity / (reorderLevel * 3) : 1;
  const pct = Math.min(Math.max(ratio, 0.04), 1) * 100;

  let tone = "bg-teal";
  let label = "In stock";
  if (quantity <= 0) {
    tone = "bg-signal-red";
    label = "Out of stock";
  } else if (quantity <= reorderLevel) {
    tone = "bg-amber";
    label = "Reorder";
  }

  return (
    <div className="flex w-32 flex-col gap-1">
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-ink/[0.08]">
        <div className={`h-full rounded-full ${tone}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="font-mono text-[11px] text-slate-mid">
        {quantity} units · {label}
      </span>
    </div>
  );
}
