import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { signUp } from "../lib/auth-client";

export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const { error: authError } = await signUp.email({ name, email, password });
    setLoading(false);
    if (authError) {
      setError(authError.message || "Could not create account.");
      return;
    }
    navigate("/");
  };

  return (
    <div className="flex min-h-[80vh] items-center justify-center px-4">
      <div className="card w-full max-w-sm p-8">
        <h1 className="font-display text-2xl font-semibold text-ink">Create account</h1>
        <p className="mt-1 text-sm text-slate-mid">Set up access to the stockroom.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="text-xs font-medium text-slate-mid">Name</label>
            <input
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="input-field mt-1"
              placeholder="Jane Doe"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-mid">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input-field mt-1"
              placeholder="you@company.com"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-mid">Password</label>
            <input
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="input-field mt-1"
              placeholder="At least 8 characters"
            />
          </div>

          {error && <p className="text-sm text-signal-red">{error}</p>}

          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading ? "Creating account..." : "Create account"}
          </button>
        </form>

        <p className="mt-5 text-center text-sm text-slate-mid">
          Already have an account?{" "}
          <Link to="/login" className="font-medium text-teal hover:text-teal-dark">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
