import { useEffect, useState } from "react";
import { api } from "../lib/api";
import StockBar from "../components/StockBar";
import ProductForm from "../components/ProductForm";

export default function Inventory() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const load = async () => {
    setLoading(true);
    const [prods, cats] = await Promise.all([
      api.products.list(search ? { search } : {}),
      api.categories.list(),
    ]);
    setProducts(prods);
    setCategories(cats);
    setLoading(false);
  };

  useEffect(() => {
    const t = setTimeout(load, 250); // debounce search
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const handleSubmit = async (data) => {
    if (editing) {
      await api.products.update(editing.id, data);
    } else {
      await api.products.create(data);
    }
    setFormOpen(false);
    setEditing(null);
    await load();
  };

  const handleDelete = async (id) => {
    if (!confirm("Remove this product from inventory?")) return;
    await api.products.remove(id);
    await load();
  };

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">Inventory</h1>
          <p className="mt-1 text-sm text-slate-mid">{products.length} products on the shelf.</p>
        </div>
        <div className="flex gap-2">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or SKU..."
            className="input-field w-56"
          />
          <button
            onClick={() => {
              setEditing(null);
              setFormOpen(true);
            }}
            className="btn-primary"
          >
            + Add product
          </button>
        </div>
      </div>

      <div className="card mt-6 overflow-hidden">
        {loading ? (
          <p className="p-6 text-sm text-slate-mid">Loading inventory...</p>
        ) : products.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm font-medium text-ink">No products yet</p>
            <p className="mt-1 text-sm text-slate-mid">Add your first product to start tracking stock.</p>
          </div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="border-b border-ink/[0.08] bg-ink/[0.02] text-xs uppercase tracking-wide text-slate-mid">
              <tr>
                <th className="px-5 py-3 font-medium">Product</th>
                <th className="px-5 py-3 font-medium">Category</th>
                <th className="px-5 py-3 font-medium">Stock level</th>
                <th className="px-5 py-3 font-medium">Unit price</th>
                <th className="px-5 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/[0.08]">
              {products.map((p) => (
                <tr key={p.id}>
                  <td className="px-5 py-3">
                    <p className="font-medium text-ink">{p.name}</p>
                    <p className="font-mono text-xs text-slate-mid">{p.sku}</p>
                  </td>
                  <td className="px-5 py-3 text-slate-mid">{p.category_name || "Uncategorized"}</td>
                  <td className="px-5 py-3">
                    <StockBar quantity={p.quantity} reorderLevel={p.reorder_level} />
                  </td>
                  <td className="px-5 py-3 text-ink">${Number(p.unit_price).toFixed(2)}</td>
                  <td className="px-5 py-3 text-right">
                    <button
                      onClick={() => {
                        setEditing(p);
                        setFormOpen(true);
                      }}
                      className="mr-3 font-medium text-teal hover:text-teal-dark"
                    >
                      Edit
                    </button>
                    <button onClick={() => handleDelete(p.id)} className="font-medium text-signal-red hover:opacity-80">
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {formOpen && (
        <ProductForm
          categories={categories}
          initial={editing}
          onSubmit={handleSubmit}
          onClose={() => {
            setFormOpen(false);
            setEditing(null);
          }}
        />
      )}
    </div>
  );
}
