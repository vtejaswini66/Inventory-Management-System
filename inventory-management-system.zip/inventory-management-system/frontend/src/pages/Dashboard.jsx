import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../lib/api";
import StockBar from "../components/StockBar";

export default function Dashboard() {
  const [products, setProducts] = useState([]);
  const [lowStock, setLowStock] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.products.list(), api.products.lowStock()])
      .then(([all, low]) => {
        setProducts(all);
        setLowStock(low);
      })
      .finally(() => setLoading(false));
  }, []);

  const totalValue = products.reduce((sum, p) => sum + p.quantity * Number(p.unit_price), 0);

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <h1 className="font-display text-2xl font-semibold text-ink">Dashboard</h1>
      <p className="mt-1 text-sm text-slate-mid">A snapshot of what's on the shelf right now.</p>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="card p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-mid">Total SKUs</p>
          <p className="mt-2 font-display text-3xl font-semibold text-ink">{products.length}</p>
        </div>
        <div className="card p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-mid">Inventory value</p>
          <p className="mt-2 font-display text-3xl font-semibold text-ink">
            ${totalValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}
          </p>
        </div>
        <div className="card p-5">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-mid">Needs reorder</p>
          <p className="mt-2 font-display text-3xl font-semibold text-signal-red">{lowStock.length}</p>
        </div>
      </div>

      <div className="card mt-6 p-5">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-ink">Reorder list</h2>
          <Link to="/inventory" className="text-sm font-medium text-teal hover:text-teal-dark">
            View full inventory →
          </Link>
        </div>

        {loading ? (
          <p className="mt-4 text-sm text-slate-mid">Loading...</p>
        ) : lowStock.length === 0 ? (
          <p className="mt-4 text-sm text-slate-mid">Nothing needs reordering. Shelves are healthy.</p>
        ) : (
          <ul className="mt-4 divide-y divide-ink/[0.08]">
            {lowStock.map((p) => (
              <li key={p.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm font-medium text-ink">{p.name}</p>
                  <p className="font-mono text-xs text-slate-mid">{p.sku}</p>
                </div>
                <StockBar quantity={p.quantity} reorderLevel={p.reorder_level} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
