import { fromNodeHeaders } from "better-auth/node";
import { auth } from "../config/auth.js";

/**
 * Verifies the Better Auth session cookie/token attached to the request
 * and attaches `req.user` / `req.session` when valid.
 */
export async function requireAuth(req, res, next) {
  try {
    const session = await auth.api.getSession({
      headers: fromNodeHeaders(req.headers),
    });

    if (!session) {
      return res.status(401).json({ error: "Unauthorized. Please sign in." });
    }

    req.user = session.user;
    req.session = session.session;
    next();
  } catch (err) {
    console.error("Auth middleware error:", err.message);
    return res.status(401).json({ error: "Unauthorized. Invalid session." });
  }
}
