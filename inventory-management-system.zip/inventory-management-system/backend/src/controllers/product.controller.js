import { pool } from "../config/db.js";

export async function listProducts(req, res, next) {
  try {
    const { search = "", category_id } = req.query;
    const params = [];
    let query = `
      SELECT p.*, c.name AS category_name
      FROM products p
      LEFT JOIN categories c ON c.id = p.category_id
      WHERE 1=1
    `;

    if (search) {
      params.push(`%${search}%`);
      query += ` AND (p.name ILIKE $${params.length} OR p.sku ILIKE $${params.length})`;
    }
    if (category_id) {
      params.push(category_id);
      query += ` AND p.category_id = $${params.length}`;
    }
    query += " ORDER BY p.updated_at DESC";

    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

export async function getProduct(req, res, next) {
  try {
    const { rows } = await pool.query(
      `SELECT p.*, c.name AS category_name
       FROM products p LEFT JOIN categories c ON c.id = p.category_id
       WHERE p.id = $1`,
      [req.params.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: "Product not found" });
    }
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

export async function createProduct(req, res, next) {
  try {
    const { sku, name, description, category_id, quantity, unit_price, reorder_level } = req.body;

    if (!sku || !name) {
      return res.status(400).json({ error: "sku and name are required" });
    }

    const { rows } = await pool.query(
      `INSERT INTO products (sku, name, description, category_id, quantity, unit_price, reorder_level, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        sku,
        name,
        description || null,
        category_id || null,
        quantity ?? 0,
        unit_price ?? 0,
        reorder_level ?? 5,
        req.user?.id || null,
      ]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
}

export async function updateProduct(req, res, next) {
  try {
    const { id } = req.params;
    const { sku, name, description, category_id, quantity, unit_price, reorder_level } = req.body;

    const { rows } = await pool.query(
      `UPDATE products SET
        sku = COALESCE($1, sku),
        name = COALESCE($2, name),
        description = COALESCE($3, description),
        category_id = COALESCE($4, category_id),
        quantity = COALESCE($5, quantity),
        unit_price = COALESCE($6, unit_price),
        reorder_level = COALESCE($7, reorder_level),
        updated_at = now()
       WHERE id = $8
       RETURNING *`,
      [sku, name, description, category_id, quantity, unit_price, reorder_level, id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: "Product not found" });
    }
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

export async function deleteProduct(req, res, next) {
  try {
    const { rowCount } = await pool.query("DELETE FROM products WHERE id = $1", [req.params.id]);
    if (rowCount === 0) {
      return res.status(404).json({ error: "Product not found" });
    }
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}

export async function lowStockProducts(req, res, next) {
  try {
    const { rows } = await pool.query(
      `SELECT * FROM products WHERE quantity <= reorder_level ORDER BY quantity ASC`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
}
