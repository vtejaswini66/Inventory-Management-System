import { Router } from "express";
import { checkDbConnection } from "../config/db.js";

const router = Router();

/**
 * GET /api/health
 * Used by Render's health check, Docker HEALTHCHECK, and uptime monitors.
 * Always returns 200 unless the process itself is unable to respond;
 * database status is reported in the body so it doesn't flap the service.
 */
router.get("/", async (req, res) => {
  const dbConnected = await checkDbConnection();

  res.status(200).json({
    status: "ok",
    service: "inventory-management-backend",
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || "development",
    database: dbConnected ? "connected" : "disconnected",
  });
});

export default router;
