import { Router } from "express";
import { requireAuth } from "../middleware/auth.middleware.js";
import { listCategories, createCategory, deleteCategory } from "../controllers/category.controller.js";

const router = Router();

router.use(requireAuth);

router.get("/", listCategories);
router.post("/", createCategory);
router.delete("/:id", deleteCategory);

export default router;
