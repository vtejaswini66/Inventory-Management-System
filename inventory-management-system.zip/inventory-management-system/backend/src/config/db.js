import pg from "pg";
import dotenv from "dotenv";

dotenv.config();

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  console.error("FATAL: DATABASE_URL is not set. Add it to your .env file.");
  process.exit(1);
}

/**
 * Neon (and most managed Postgres providers) require SSL.
 * `sslmode=require` is also typically present directly in the Neon
 * connection string, but we set it explicitly here as a safety net.
 */
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

pool.on("error", (err) => {
  console.error("Unexpected error on idle PostgreSQL client", err);
});

export async function checkDbConnection() {
  try {
    await pool.query("SELECT 1");
    return true;
  } catch (err) {
    console.error("Database health check failed:", err.message);
    return false;
  }
}
