import { betterAuth } from "better-auth";
import { pool } from "./db.js";
import dotenv from "dotenv";

dotenv.config();

const trustedOrigins = (process.env.FRONTEND_URL || "http://localhost:5173")
  .split(",")
  .map((origin) => origin.trim());

/**
 * Better Auth instance.
 * - `database` accepts a raw `pg.Pool` directly; Better Auth detects the
 *   driver and runs Postgres-flavoured SQL under the hood.
 * - Run `npx @better-auth/cli generate` (or apply backend/src/db/schema.sql
 *   manually) against your Neon database before first use, this creates the
 *   user / session / account / verification tables Better Auth needs.
 */
export const auth = betterAuth({
  database: pool,
  secret: process.env.BETTER_AUTH_SECRET,
  baseURL: process.env.BETTER_AUTH_URL || "http://localhost:4000",
  trustedOrigins,
  emailAndPassword: {
    enabled: true,
    autoSignIn: true,
    minPasswordLength: 8,
  },
  session: {
    expiresIn: 60 * 60 * 24 * 7, // 7 days
    updateAge: 60 * 60 * 24, // refresh once per day of activity
  },
  advanced: {
    defaultCookieAttributes: {
      sameSite: "none",
      secure: true,
    },
  },
});
