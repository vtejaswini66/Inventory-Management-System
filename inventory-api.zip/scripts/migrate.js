require('dotenv').config();
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

const pool = new Pool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT, 10),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

const MIGRATIONS_DIR = path.join(__dirname, '..', 'migrations');

const runMigrations = async () => {
  const client = await pool.connect();
  try {
    console.log('🔌 Connected to database');

    // Ensure migration tracking table exists
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version VARCHAR(50) PRIMARY KEY,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    const appliedRes = await client.query('SELECT version FROM schema_migrations');
    const applied = new Set(appliedRes.rows.map((r) => r.version));

    const files = fs.readdirSync(MIGRATIONS_DIR)
      .filter((f) => f.endsWith('.sql'))
      .sort();

    let ran = 0;
    for (const file of files) {
      const version = path.basename(file, '.sql');
      if (applied.has(version)) {
        console.log(`⏭  Skipping ${file} (already applied)`);
        continue;
      }
      console.log(`▶  Applying ${file}...`);
      const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf8');
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query('COMMIT');
        console.log(`✅ Applied ${file}`);
        ran++;
      } catch (err) {
        await client.query('ROLLBACK');
        console.error(`❌ Failed on ${file}:`, err.message);
        process.exit(1);
      }
    }

    if (ran === 0) console.log('✨ All migrations already up to date');
    else console.log(`🎉 ${ran} migration(s) applied`);
  } finally {
    client.release();
    await pool.end();
  }
};

runMigrations().catch((err) => {
  console.error('Migration error:', err);
  process.exit(1);
});
