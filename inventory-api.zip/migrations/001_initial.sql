-- ============================================================
-- Inventory Management System — Database Migration
-- Run: node scripts/migrate.js
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── Migration tracking ────────────────────────────────────
CREATE TABLE IF NOT EXISTS schema_migrations (
  version     VARCHAR(50) PRIMARY KEY,
  applied_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Better Auth tables ────────────────────────────────────
CREATE TABLE IF NOT EXISTS "user" (
  id              TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  name            TEXT NOT NULL,
  email           TEXT NOT NULL UNIQUE,
  email_verified  BOOLEAN NOT NULL DEFAULT FALSE,
  image           TEXT,
  role            TEXT NOT NULL DEFAULT 'staff' CHECK (role IN ('admin', 'manager', 'staff')),
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS session (
  id              TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  expires_at      TIMESTAMPTZ NOT NULL,
  token           TEXT NOT NULL UNIQUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ip_address      TEXT,
  user_agent      TEXT,
  user_id         TEXT NOT NULL REFERENCES "user"(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS account (
  id                      TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  account_id              TEXT NOT NULL,
  provider_id             TEXT NOT NULL,
  user_id                 TEXT NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
  access_token            TEXT,
  refresh_token           TEXT,
  id_token                TEXT,
  access_token_expires_at TIMESTAMPTZ,
  refresh_token_expires_at TIMESTAMPTZ,
  scope                   TEXT,
  password                TEXT,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (provider_id, account_id)
);

CREATE TABLE IF NOT EXISTS verification (
  id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  identifier  TEXT NOT NULL,
  value       TEXT NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Categories ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(100) NOT NULL,
  description TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at  TIMESTAMPTZ,
  CONSTRAINT uq_categories_name_active UNIQUE (name)
);

CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name) WHERE deleted_at IS NULL;

-- ── Suppliers ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS suppliers (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            VARCHAR(200) NOT NULL,
  email           VARCHAR(255) UNIQUE,
  phone           VARCHAR(30),
  contact_person  VARCHAR(200),
  address         TEXT,
  notes           TEXT,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_suppliers_name   ON suppliers(name)    WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_suppliers_email  ON suppliers(email)   WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_suppliers_active ON suppliers(is_active) WHERE deleted_at IS NULL;

-- ── Products ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(200) NOT NULL,
  sku           VARCHAR(100) NOT NULL UNIQUE,
  description   TEXT,
  category_id   UUID REFERENCES categories(id) ON DELETE SET NULL,
  supplier_id   UUID REFERENCES suppliers(id)  ON DELETE SET NULL,
  unit_price    NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
  cost_price    NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (cost_price >= 0),
  quantity      INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  reorder_level INTEGER NOT NULL DEFAULT 0 CHECK (reorder_level >= 0),
  unit          VARCHAR(50) NOT NULL DEFAULT 'pcs',
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_products_sku        ON products(sku) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_products_category   ON products(category_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_products_supplier   ON products(supplier_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_products_low_stock  ON products(quantity, reorder_level) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_products_name_trgm  ON products USING gin(name gin_trgm_ops) WHERE deleted_at IS NULL;

-- ── Inventory Transactions ────────────────────────────────
CREATE TABLE IF NOT EXISTS inventory_transactions (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id   UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  type         VARCHAR(20) NOT NULL CHECK (type IN ('stock_in', 'stock_out', 'adjustment', 'transfer')),
  quantity     INTEGER NOT NULL,
  unit_cost    NUMERIC(12, 2) NOT NULL DEFAULT 0,
  total_cost   NUMERIC(14, 2) NOT NULL DEFAULT 0,
  reference    VARCHAR(100),
  supplier_id  UUID REFERENCES suppliers(id) ON DELETE SET NULL,
  notes        TEXT,
  created_by   TEXT REFERENCES "user"(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_inv_product    ON inventory_transactions(product_id);
CREATE INDEX IF NOT EXISTS idx_inv_type       ON inventory_transactions(type);
CREATE INDEX IF NOT EXISTS idx_inv_created_at ON inventory_transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_inv_reference  ON inventory_transactions(reference) WHERE reference IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_inv_supplier   ON inventory_transactions(supplier_id) WHERE supplier_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_inv_created_by ON inventory_transactions(created_by) WHERE created_by IS NOT NULL;

-- ── updated_at auto-trigger ───────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_categories_updated_at') THEN
    CREATE TRIGGER trg_categories_updated_at BEFORE UPDATE ON categories FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_suppliers_updated_at') THEN
    CREATE TRIGGER trg_suppliers_updated_at BEFORE UPDATE ON suppliers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_products_updated_at') THEN
    CREATE TRIGGER trg_products_updated_at BEFORE UPDATE ON products FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_user_updated_at') THEN
    CREATE TRIGGER trg_user_updated_at BEFORE UPDATE ON "user" FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

-- ── Seed: default admin user ──────────────────────────────
-- Password: Admin@123 (bcrypt hash — change immediately after first login)
INSERT INTO "user" (id, name, email, email_verified, role, is_active)
VALUES (
  gen_random_uuid()::text,
  'Super Admin',
  'admin@inventory.local',
  TRUE,
  'admin',
  TRUE
) ON CONFLICT (email) DO NOTHING;

-- ── Seed: sample categories ───────────────────────────────
INSERT INTO categories (name, description) VALUES
  ('Electronics',  'Electronic components and devices'),
  ('Office Supplies', 'Stationery and office consumables'),
  ('Raw Materials', 'Raw manufacturing inputs')
ON CONFLICT (name) DO NOTHING;

-- Record migration
INSERT INTO schema_migrations (version) VALUES ('001_initial')
ON CONFLICT (version) DO NOTHING;
