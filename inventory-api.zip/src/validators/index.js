const { body, param, query } = require('express-validator');

// ── Shared ──────────────────────────────────────────────
const uuidParam = (field = 'id') => param(field).isUUID().withMessage(`${field} must be a valid UUID`);
const pageQuery = () => query('page').optional().isInt({ min: 1 }).withMessage('page must be a positive integer');
const limitQuery = () => query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('limit must be 1–100');

// ── Category ─────────────────────────────────────────────
const categoryCreate = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 100 }),
  body('description').optional().trim().isLength({ max: 500 }),
];
const categoryUpdate = [
  uuidParam(),
  body('name').optional().trim().notEmpty().isLength({ max: 100 }),
  body('description').optional().trim().isLength({ max: 500 }),
];

// ── Supplier ─────────────────────────────────────────────
const supplierCreate = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 200 }),
  body('email').optional().isEmail().withMessage('Must be a valid email').normalizeEmail(),
  body('phone').optional().trim().isLength({ max: 30 }),
  body('contactPerson').optional().trim().isLength({ max: 200 }),
  body('address').optional().trim().isLength({ max: 500 }),
  body('notes').optional().trim(),
];
const supplierUpdate = [
  uuidParam(),
  ...supplierCreate.map((v) => v.optional ? v : v.optional()),
  body('isActive').optional().isBoolean().withMessage('isActive must be boolean'),
];

// ── Product ───────────────────────────────────────────────
const productCreate = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 200 }),
  body('sku').trim().notEmpty().withMessage('SKU is required').isLength({ max: 100 }),
  body('description').optional().trim(),
  body('categoryId').optional().isUUID().withMessage('categoryId must be a valid UUID'),
  body('supplierId').optional().isUUID().withMessage('supplierId must be a valid UUID'),
  body('unitPrice').notEmpty().isFloat({ min: 0 }).withMessage('unitPrice must be >= 0'),
  body('costPrice').optional().isFloat({ min: 0 }),
  body('quantity').optional().isInt({ min: 0 }).withMessage('quantity must be >= 0'),
  body('reorderLevel').optional().isInt({ min: 0 }),
  body('unit').optional().trim().isLength({ max: 50 }),
];
const productUpdate = [
  uuidParam(),
  body('name').optional().trim().notEmpty().isLength({ max: 200 }),
  body('sku').optional().trim().notEmpty().isLength({ max: 100 }),
  body('categoryId').optional().isUUID(),
  body('supplierId').optional().isUUID(),
  body('unitPrice').optional().isFloat({ min: 0 }),
  body('costPrice').optional().isFloat({ min: 0 }),
  body('reorderLevel').optional().isInt({ min: 0 }),
  body('unit').optional().trim(),
  body('isActive').optional().isBoolean(),
];

// ── Inventory ─────────────────────────────────────────────
const stockIn = [
  body('productId').isUUID().withMessage('productId must be a valid UUID'),
  body('quantity').isInt({ min: 1 }).withMessage('quantity must be >= 1'),
  body('unitCost').optional().isFloat({ min: 0 }),
  body('reference').optional().trim().isLength({ max: 100 }),
  body('supplierId').optional().isUUID(),
  body('notes').optional().trim(),
];
const stockOut = [
  body('productId').isUUID().withMessage('productId must be a valid UUID'),
  body('quantity').isInt({ min: 1 }).withMessage('quantity must be >= 1'),
  body('reference').optional().trim().isLength({ max: 100 }),
  body('notes').optional().trim(),
];
const adjust = [
  body('productId').isUUID().withMessage('productId must be a valid UUID'),
  body('quantity').isInt().withMessage('quantity must be an integer (positive or negative)'),
  body('reference').optional().trim().isLength({ max: 100 }),
  body('notes').optional().trim(),
];

module.exports = {
  uuidParam, pageQuery, limitQuery,
  category: { create: categoryCreate, update: categoryUpdate },
  supplier: { create: supplierCreate, update: supplierUpdate },
  product: { create: productCreate, update: productUpdate },
  inventory: { stockIn, stockOut, adjust },
};
