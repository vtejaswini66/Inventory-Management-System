const router = require('express').Router();
const { auth } = require('../config/auth');
const { authenticate } = require('../middleware/authenticate');
const { authorize, adminOnly, managerOrAbove } = require('../middleware/authorize');
const { validate } = require('../middleware/validate');
const v = require('../validators');

const CategoryController = require('../controllers/category.controller');
const SupplierController = require('../controllers/supplier.controller');
const ProductController = require('../controllers/product.controller');
const InventoryController = require('../controllers/inventory.controller');
const DashboardController = require('../controllers/dashboard.controller');

// ── Health ────────────────────────────────────────────────
router.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), version: process.env.npm_package_version || '1.0.0' });
});

// ── Auth (Better Auth handles /api/auth/**) ───────────────
// POST /api/auth/sign-up/email
// POST /api/auth/sign-in/email
// POST /api/auth/sign-out
// GET  /api/auth/session
// GET  /api/auth/user
// (all handled by better-auth toNodeHandler)

// ── Categories ────────────────────────────────────────────
const catRouter = require('express').Router();
catRouter.get('/', authenticate, v.pageQuery(), v.limitQuery(), validate, CategoryController.getAll);
catRouter.get('/:id', authenticate, v.uuidParam(), validate, CategoryController.getById);
catRouter.post('/', authenticate, managerOrAbove, v.category.create, validate, CategoryController.create);
catRouter.put('/:id', authenticate, managerOrAbove, v.category.update, validate, CategoryController.update);
catRouter.delete('/:id', authenticate, adminOnly, v.uuidParam(), validate, CategoryController.delete);
router.use('/categories', catRouter);

// ── Suppliers ─────────────────────────────────────────────
const supRouter = require('express').Router();
supRouter.get('/', authenticate, v.pageQuery(), v.limitQuery(), validate, SupplierController.getAll);
supRouter.get('/:id', authenticate, v.uuidParam(), validate, SupplierController.getById);
supRouter.post('/', authenticate, managerOrAbove, v.supplier.create, validate, SupplierController.create);
supRouter.put('/:id', authenticate, managerOrAbove, v.supplier.update, validate, SupplierController.update);
supRouter.delete('/:id', authenticate, adminOnly, v.uuidParam(), validate, SupplierController.delete);
router.use('/suppliers', supRouter);

// ── Products ──────────────────────────────────────────────
const prodRouter = require('express').Router();
prodRouter.get('/low-stock', authenticate, ProductController.getLowStock);
prodRouter.get('/', authenticate, v.pageQuery(), v.limitQuery(), validate, ProductController.getAll);
prodRouter.get('/:id', authenticate, v.uuidParam(), validate, ProductController.getById);
prodRouter.post('/', authenticate, managerOrAbove, v.product.create, validate, ProductController.create);
prodRouter.put('/:id', authenticate, managerOrAbove, v.product.update, validate, ProductController.update);
prodRouter.delete('/:id', authenticate, adminOnly, v.uuidParam(), validate, ProductController.delete);
router.use('/products', prodRouter);

// ── Inventory ─────────────────────────────────────────────
const invRouter = require('express').Router();
invRouter.post('/stock-in', authenticate, v.inventory.stockIn, validate, InventoryController.stockIn);
invRouter.post('/stock-out', authenticate, v.inventory.stockOut, validate, InventoryController.stockOut);
invRouter.post('/adjust', authenticate, managerOrAbove, v.inventory.adjust, validate, InventoryController.adjust);
invRouter.get('/transactions', authenticate, v.pageQuery(), v.limitQuery(), validate, InventoryController.getTransactions);
invRouter.get('/transactions/:id', authenticate, v.uuidParam(), validate, InventoryController.getTransactionById);
invRouter.get('/summary/:productId', authenticate, v.uuidParam('productId'), validate, InventoryController.getProductSummary);
router.use('/inventory', invRouter);

// ── Dashboard ─────────────────────────────────────────────
const dashRouter = require('express').Router();
dashRouter.get('/', authenticate, managerOrAbove, DashboardController.getAnalytics);
dashRouter.get('/overview', authenticate, DashboardController.getOverview);
dashRouter.get('/stock-movement', authenticate, DashboardController.getStockMovement);
router.use('/dashboard', dashRouter);

// ── Admin: User management ────────────────────────────────
const userRouter = require('express').Router();
userRouter.get('/', authenticate, adminOnly, async (req, res, next) => {
  try {
    const { query } = require('../config/database');
    const result = await query(`SELECT id, name, email, role, is_active, created_at FROM "user" ORDER BY created_at DESC`);
    res.json({ success: true, data: result.rows });
  } catch (err) { next(err); }
});
userRouter.patch('/:id/role', authenticate, adminOnly, async (req, res, next) => {
  try {
    const { role } = req.body;
    if (!['admin', 'manager', 'staff'].includes(role)) {
      return res.status(400).json({ success: false, message: 'Invalid role' });
    }
    const { query } = require('../config/database');
    const result = await query(
      `UPDATE "user" SET role = $1, updated_at = NOW() WHERE id = $2 RETURNING id, name, email, role`,
      [role, req.params.id]
    );
    res.json({ success: true, data: result.rows[0] });
  } catch (err) { next(err); }
});
userRouter.patch('/:id/status', authenticate, adminOnly, async (req, res, next) => {
  try {
    const { isActive } = req.body;
    const { query } = require('../config/database');
    const result = await query(
      `UPDATE "user" SET is_active = $1, updated_at = NOW() WHERE id = $2 RETURNING id, name, email, is_active`,
      [isActive, req.params.id]
    );
    res.json({ success: true, data: result.rows[0] });
  } catch (err) { next(err); }
});
router.use('/users', userRouter);

module.exports = router;
