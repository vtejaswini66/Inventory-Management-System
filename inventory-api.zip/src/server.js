require('dotenv').config();
const app = require('./app');
const { testConnection } = require('./config/database');
const logger = require('./utils/logger');

const PORT = parseInt(process.env.PORT, 10) || 3000;

const startServer = async () => {
  // Verify DB connection before accepting traffic
  const dbOk = await testConnection();
  if (!dbOk) {
    logger.error('Cannot connect to database. Exiting.');
    process.exit(1);
  }

  const server = app.listen(PORT, () => {
    logger.info(`🚀 Server running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
    logger.info(`📦 API: http://localhost:${PORT}/api/${process.env.API_VERSION || 'v1'}`);
    logger.info(`🔐 Auth: http://localhost:${PORT}/api/auth`);
  });

  // Graceful shutdown
  const shutdown = async (signal) => {
    logger.info(`${signal} received — shutting down gracefully`);
    server.close(() => {
      logger.info('HTTP server closed');
      const { pool } = require('./config/database');
      pool.end(() => {
        logger.info('Database pool closed');
        process.exit(0);
      });
    });
    // Force exit after 10s
    setTimeout(() => { logger.error('Forced exit'); process.exit(1); }, 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
};

startServer();
