const sendSuccess = (res, data = null, message = 'Success', statusCode = 200, meta = {}) => {
  const response = {
    success: true,
    message,
    data,
  };
  if (Object.keys(meta).length) response.meta = meta;
  return res.status(statusCode).json(response);
};

const sendCreated = (res, data = null, message = 'Resource created successfully') => {
  return sendSuccess(res, data, message, 201);
};

const sendError = (res, message = 'Internal server error', statusCode = 500, errors = null) => {
  const response = {
    success: false,
    message,
  };
  if (errors) response.errors = errors;
  return res.status(statusCode).json(response);
};

const sendNotFound = (res, message = 'Resource not found') => {
  return sendError(res, message, 404);
};

const sendBadRequest = (res, message = 'Bad request', errors = null) => {
  return sendError(res, message, 400, errors);
};

const sendUnauthorized = (res, message = 'Unauthorized') => {
  return sendError(res, message, 401);
};

const sendForbidden = (res, message = 'Forbidden') => {
  return sendError(res, message, 403);
};

const sendConflict = (res, message = 'Resource already exists') => {
  return sendError(res, message, 409);
};

const paginate = (page = 1, limit = 20, total = 0) => {
  const currentPage = Math.max(1, parseInt(page, 10));
  const perPage = Math.min(100, Math.max(1, parseInt(limit, 10)));
  const offset = (currentPage - 1) * perPage;
  const totalPages = Math.ceil(total / perPage);
  return {
    pagination: { currentPage, perPage, total, totalPages, hasNext: currentPage < totalPages, hasPrev: currentPage > 1 },
    offset,
    limit: perPage,
  };
};

module.exports = {
  sendSuccess, sendCreated, sendError, sendNotFound,
  sendBadRequest, sendUnauthorized, sendForbidden, sendConflict, paginate,
};
