const { betterAuth } = require('better-auth');
const { Pool } = require('pg');

const authPool = new Pool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT, 10),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

const auth = betterAuth({
  secret: process.env.BETTER_AUTH_SECRET,
  baseURL: process.env.BETTER_AUTH_URL,
  database: {
    type: 'pg',
    pool: authPool,
  },
  session: {
    expiresIn: parseInt(process.env.SESSION_EXPIRY_SECONDS, 10) || 86400,
    updateAge: 3600,
  },
  emailAndPassword: {
    enabled: true,
    requireEmailVerification: false,
    minPasswordLength: 8,
  },
  user: {
    additionalFields: {
      role: {
        type: 'string',
        defaultValue: 'staff',
        required: false,
      },
      isActive: {
        type: 'boolean',
        defaultValue: true,
        required: false,
        fieldName: 'is_active',
      },
    },
  },
  trustedOrigins: process.env.BETTER_AUTH_URL ? [process.env.BETTER_AUTH_URL] : [],
  advanced: {
    useSecureCookies: process.env.NODE_ENV === 'production',
    crossSubDomainCookies: {
      enabled: false,
    },
  },
});

module.exports = { auth };
