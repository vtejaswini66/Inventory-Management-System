const { query } = require('../config/database');

const CategoryModel = {
  async findAll({ limit, offset, search }) {
    let sql = `SELECT * FROM categories WHERE deleted_at IS NULL`;
    const params = [];
    if (search) {
      params.push(`%${search}%`);
      sql += ` AND (name ILIKE $${params.length} OR description ILIKE $${params.length})`;
    }
    const countRes = await query(sql.replace('*', 'COUNT(*)'), params);
    const total = parseInt(countRes.rows[0].count, 10);
    params.push(limit, offset);
    sql += ` ORDER BY name ASC LIMIT $${params.length - 1} OFFSET $${params.length}`;
    const res = await query(sql, params);
    return { rows: res.rows, total };
  },

  async findById(id) {
    const res = await query('SELECT * FROM categories WHERE id = $1 AND deleted_at IS NULL', [id]);
    return res.rows[0] || null;
  },

  async findByName(name) {
    const res = await query('SELECT * FROM categories WHERE LOWER(name) = LOWER($1) AND deleted_at IS NULL', [name]);
    return res.rows[0] || null;
  },

  async create({ name, description }) {
    const res = await query(
      `INSERT INTO categories (name, description) VALUES ($1, $2) RETURNING *`,
      [name, description || null]
    );
    return res.rows[0];
  },

  async update(id, { name, description }) {
    const res = await query(
      `UPDATE categories SET name = COALESCE($1, name), description = COALESCE($2, description), updated_at = NOW()
       WHERE id = $3 AND deleted_at IS NULL RETURNING *`,
      [name, description, id]
    );
    return res.rows[0] || null;
  },

  async delete(id) {
    const res = await query(
      `UPDATE categories SET deleted_at = NOW() WHERE id = $1 AND deleted_at IS NULL RETURNING id`,
      [id]
    );
    return res.rowCount > 0;
  },
};

module.exports = CategoryModel;
