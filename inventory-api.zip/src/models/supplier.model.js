const { query } = require('../config/database');

const SupplierModel = {
  async findAll({ limit, offset, search, isActive }) {
    let sql = `SELECT * FROM suppliers WHERE deleted_at IS NULL`;
    const params = [];
    if (search) {
      params.push(`%${search}%`);
      sql += ` AND (name ILIKE $${params.length} OR email ILIKE $${params.length} OR contact_person ILIKE $${params.length})`;
    }
    if (isActive !== undefined) {
      params.push(isActive);
      sql += ` AND is_active = $${params.length}`;
    }
    const countRes = await query(sql.replace('SELECT *', 'SELECT COUNT(*)'), params);
    const total = parseInt(countRes.rows[0].count, 10);
    params.push(limit, offset);
    sql += ` ORDER BY name ASC LIMIT $${params.length - 1} OFFSET $${params.length}`;
    const res = await query(sql, params);
    return { rows: res.rows, total };
  },

  async findById(id) {
    const res = await query('SELECT * FROM suppliers WHERE id = $1 AND deleted_at IS NULL', [id]);
    return res.rows[0] || null;
  },

  async findByEmail(email) {
    const res = await query('SELECT * FROM suppliers WHERE email = $1 AND deleted_at IS NULL', [email]);
    return res.rows[0] || null;
  },

  async create({ name, email, phone, contactPerson, address, notes }) {
    const res = await query(
      `INSERT INTO suppliers (name, email, phone, contact_person, address, notes)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [name, email || null, phone || null, contactPerson || null, address || null, notes || null]
    );
    return res.rows[0];
  },

  async update(id, { name, email, phone, contactPerson, address, notes, isActive }) {
    const res = await query(
      `UPDATE suppliers SET
        name = COALESCE($1, name),
        email = COALESCE($2, email),
        phone = COALESCE($3, phone),
        contact_person = COALESCE($4, contact_person),
        address = COALESCE($5, address),
        notes = COALESCE($6, notes),
        is_active = COALESCE($7, is_active),
        updated_at = NOW()
       WHERE id = $8 AND deleted_at IS NULL RETURNING *`,
      [name, email, phone, contactPerson, address, notes, isActive, id]
    );
    return res.rows[0] || null;
  },

  async delete(id) {
    const res = await query(
      `UPDATE suppliers SET deleted_at = NOW() WHERE id = $1 AND deleted_at IS NULL RETURNING id`,
      [id]
    );
    return res.rowCount > 0;
  },
};

module.exports = SupplierModel;
