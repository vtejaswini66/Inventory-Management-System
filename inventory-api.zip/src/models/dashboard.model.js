const { query } = require('../config/database');

const DashboardModel = {
  async getOverview() {
    const [products, categories, suppliers, lowStock, transactions] = await Promise.all([
      query(`SELECT COUNT(*) AS total, SUM(quantity * unit_price) AS total_value FROM products WHERE deleted_at IS NULL AND is_active = true`),
      query(`SELECT COUNT(*) AS total FROM categories WHERE deleted_at IS NULL`),
      query(`SELECT COUNT(*) AS total FROM suppliers WHERE deleted_at IS NULL AND is_active = true`),
      query(`SELECT COUNT(*) AS total FROM products WHERE quantity <= reorder_level AND deleted_at IS NULL AND is_active = true`),
      query(`SELECT COUNT(*) AS total FROM inventory_transactions WHERE created_at >= NOW() - INTERVAL '30 days'`),
    ]);
    return {
      totalProducts: parseInt(products.rows[0].total, 10),
      inventoryValue: parseFloat(products.rows[0].total_value || 0),
      totalCategories: parseInt(categories.rows[0].total, 10),
      activeSuppliers: parseInt(suppliers.rows[0].total, 10),
      lowStockAlerts: parseInt(lowStock.rows[0].total, 10),
      transactionsThisMonth: parseInt(transactions.rows[0].total, 10),
    };
  },

  async getStockMovement({ days = 30 } = {}) {
    const res = await query(
      `SELECT
        DATE(created_at) AS date,
        SUM(CASE WHEN type = 'stock_in' THEN quantity ELSE 0 END) AS stock_in,
        SUM(CASE WHEN type = 'stock_out' THEN quantity ELSE 0 END) AS stock_out
       FROM inventory_transactions
       WHERE created_at >= NOW() - INTERVAL '${parseInt(days, 10)} days'
       GROUP BY DATE(created_at)
       ORDER BY date ASC`
    );
    return res.rows;
  },

  async getTopProducts({ limit = 10 } = {}) {
    const res = await query(
      `SELECT
        p.id, p.name, p.sku, p.quantity, p.unit_price,
        p.quantity * p.unit_price AS total_value,
        c.name AS category_name,
        COALESCE(SUM(CASE WHEN t.type = 'stock_out' THEN t.quantity ELSE 0 END), 0) AS total_sold
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN inventory_transactions t ON p.id = t.product_id AND t.created_at >= NOW() - INTERVAL '30 days'
       WHERE p.deleted_at IS NULL AND p.is_active = true
       GROUP BY p.id, c.name
       ORDER BY total_sold DESC
       LIMIT $1`,
      [parseInt(limit, 10)]
    );
    return res.rows;
  },

  async getCategoryBreakdown() {
    const res = await query(
      `SELECT
        c.name AS category,
        COUNT(p.id) AS product_count,
        COALESCE(SUM(p.quantity), 0) AS total_quantity,
        COALESCE(SUM(p.quantity * p.unit_price), 0) AS total_value
       FROM categories c
       LEFT JOIN products p ON p.category_id = c.id AND p.deleted_at IS NULL AND p.is_active = true
       WHERE c.deleted_at IS NULL
       GROUP BY c.id, c.name
       ORDER BY total_value DESC`
    );
    return res.rows;
  },

  async getRecentTransactions({ limit = 10 } = {}) {
    const res = await query(
      `SELECT t.id, t.type, t.quantity, t.unit_cost, t.total_cost, t.reference, t.created_at,
              p.name AS product_name, p.sku, u.name AS created_by_name
       FROM inventory_transactions t
       LEFT JOIN products p ON t.product_id = p.id
       LEFT JOIN "user" u ON t.created_by = u.id
       ORDER BY t.created_at DESC
       LIMIT $1`,
      [parseInt(limit, 10)]
    );
    return res.rows;
  },

  async getLowStockProducts({ limit = 20 } = {}) {
    const res = await query(
      `SELECT p.id, p.name, p.sku, p.quantity, p.reorder_level, p.unit,
              c.name AS category_name, s.name AS supplier_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN suppliers s ON p.supplier_id = s.id
       WHERE p.quantity <= p.reorder_level AND p.deleted_at IS NULL AND p.is_active = true
       ORDER BY p.quantity ASC
       LIMIT $1`,
      [parseInt(limit, 10)]
    );
    return res.rows;
  },
};

module.exports = DashboardModel;
