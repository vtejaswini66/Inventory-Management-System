const { query } = require('../config/database');

const InventoryModel = {
  async createTransaction(client, {
    productId, type, quantity, unitCost, reference,
    supplierId, notes, createdBy
  }) {
    const totalCost = (unitCost || 0) * quantity;
    const res = await client.query(
      `INSERT INTO inventory_transactions
        (product_id, type, quantity, unit_cost, total_cost, reference, supplier_id, notes, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [productId, type, quantity, unitCost || 0, totalCost,
       reference || null, supplierId || null, notes || null, createdBy]
    );
    return res.rows[0];
  },

  async findAll({ limit, offset, productId, type, startDate, endDate, search }) {
    let sql = `
      SELECT t.*, p.name AS product_name, p.sku,
             s.name AS supplier_name, u.name AS created_by_name
      FROM inventory_transactions t
      LEFT JOIN products p ON t.product_id = p.id
      LEFT JOIN suppliers s ON t.supplier_id = s.id
      LEFT JOIN "user" u ON t.created_by = u.id
      WHERE 1=1
    `;
    const params = [];
    if (productId) { params.push(productId); sql += ` AND t.product_id = $${params.length}`; }
    if (type) { params.push(type); sql += ` AND t.type = $${params.length}`; }
    if (startDate) { params.push(startDate); sql += ` AND t.created_at >= $${params.length}`; }
    if (endDate) { params.push(endDate); sql += ` AND t.created_at <= $${params.length}`; }
    if (search) {
      params.push(`%${search}%`);
      sql += ` AND (p.name ILIKE $${params.length} OR t.reference ILIKE $${params.length} OR t.notes ILIKE $${params.length})`;
    }

    const countRes = await query(
      sql.replace(/SELECT t\.\*.*FROM inventory_transactions t/s, 'SELECT COUNT(*) FROM inventory_transactions t').replace(/ ORDER BY.*/s, ''),
      params
    );
    const total = parseInt(countRes.rows[0].count, 10);

    params.push(limit, offset);
    sql += ` ORDER BY t.created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`;
    const res = await query(sql, params);
    return { rows: res.rows, total };
  },

  async findById(id) {
    const res = await query(
      `SELECT t.*, p.name AS product_name, p.sku, s.name AS supplier_name, u.name AS created_by_name
       FROM inventory_transactions t
       LEFT JOIN products p ON t.product_id = p.id
       LEFT JOIN suppliers s ON t.supplier_id = s.id
       LEFT JOIN "user" u ON t.created_by = u.id
       WHERE t.id = $1`,
      [id]
    );
    return res.rows[0] || null;
  },

  async getSummaryByProduct(productId) {
    const res = await query(
      `SELECT
        SUM(CASE WHEN type = 'stock_in' THEN quantity ELSE 0 END) AS total_in,
        SUM(CASE WHEN type = 'stock_out' THEN quantity ELSE 0 END) AS total_out,
        SUM(CASE WHEN type = 'adjustment' AND quantity > 0 THEN quantity ELSE 0 END) AS total_adj_in,
        SUM(CASE WHEN type = 'adjustment' AND quantity < 0 THEN ABS(quantity) ELSE 0 END) AS total_adj_out,
        COUNT(*) AS transaction_count
       FROM inventory_transactions WHERE product_id = $1`,
      [productId]
    );
    return res.rows[0];
  },
};

module.exports = InventoryModel;
