const { query } = require('../config/database');

const ProductModel = {
  async findAll({ limit, offset, search, categoryId, supplierId, lowStock }) {
    let sql = `
      SELECT p.*, c.name AS category_name, s.name AS supplier_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN suppliers s ON p.supplier_id = s.id
      WHERE p.deleted_at IS NULL
    `;
    const params = [];
    if (search) {
      params.push(`%${search}%`);
      sql += ` AND (p.name ILIKE $${params.length} OR p.sku ILIKE $${params.length} OR p.description ILIKE $${params.length})`;
    }
    if (categoryId) { params.push(categoryId); sql += ` AND p.category_id = $${params.length}`; }
    if (supplierId) { params.push(supplierId); sql += ` AND p.supplier_id = $${params.length}`; }
    if (lowStock) { sql += ` AND p.quantity <= p.reorder_level`; }

    const countSql = `SELECT COUNT(*) FROM products p WHERE p.deleted_at IS NULL${params.length ? '' : ''}`;
    const countRes = await query(sql.replace(
      /SELECT p\.\*.*FROM products p/s,
      'SELECT COUNT(*) FROM products p'
    ).replace(/ ORDER BY.*/s, ''), params);
    const total = parseInt(countRes.rows[0].count, 10);

    params.push(limit, offset);
    sql += ` ORDER BY p.name ASC LIMIT $${params.length - 1} OFFSET $${params.length}`;
    const res = await query(sql, params);
    return { rows: res.rows, total };
  },

  async findById(id) {
    const res = await query(
      `SELECT p.*, c.name AS category_name, s.name AS supplier_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN suppliers s ON p.supplier_id = s.id
       WHERE p.id = $1 AND p.deleted_at IS NULL`,
      [id]
    );
    return res.rows[0] || null;
  },

  async findBySku(sku) {
    const res = await query('SELECT * FROM products WHERE sku = $1 AND deleted_at IS NULL', [sku]);
    return res.rows[0] || null;
  },

  async create({ name, sku, description, categoryId, supplierId, unitPrice, costPrice, quantity, reorderLevel, unit }) {
    const res = await query(
      `INSERT INTO products (name, sku, description, category_id, supplier_id, unit_price, cost_price, quantity, reorder_level, unit)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [name, sku, description || null, categoryId || null, supplierId || null,
       unitPrice, costPrice || 0, quantity || 0, reorderLevel || 0, unit || 'pcs']
    );
    return res.rows[0];
  },

  async update(id, fields) {
    const { name, sku, description, categoryId, supplierId, unitPrice, costPrice, reorderLevel, unit, isActive } = fields;
    const res = await query(
      `UPDATE products SET
        name = COALESCE($1, name),
        sku = COALESCE($2, sku),
        description = COALESCE($3, description),
        category_id = COALESCE($4, category_id),
        supplier_id = COALESCE($5, supplier_id),
        unit_price = COALESCE($6, unit_price),
        cost_price = COALESCE($7, cost_price),
        reorder_level = COALESCE($8, reorder_level),
        unit = COALESCE($9, unit),
        is_active = COALESCE($10, is_active),
        updated_at = NOW()
       WHERE id = $11 AND deleted_at IS NULL RETURNING *`,
      [name, sku, description, categoryId, supplierId, unitPrice, costPrice, reorderLevel, unit, isActive, id]
    );
    return res.rows[0] || null;
  },

  async updateQuantity(client, id, quantityDelta) {
    const res = await client.query(
      `UPDATE products SET quantity = quantity + $1, updated_at = NOW()
       WHERE id = $2 AND deleted_at IS NULL RETURNING *`,
      [quantityDelta, id]
    );
    return res.rows[0] || null;
  },

  async delete(id) {
    const res = await query(
      `UPDATE products SET deleted_at = NOW() WHERE id = $1 AND deleted_at IS NULL RETURNING id`,
      [id]
    );
    return res.rowCount > 0;
  },

  async getLowStockProducts() {
    const res = await query(
      `SELECT p.*, c.name AS category_name FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.quantity <= p.reorder_level AND p.deleted_at IS NULL AND p.is_active = true
       ORDER BY p.quantity ASC`
    );
    return res.rows;
  },
};

module.exports = ProductModel;
