const ProductModel = require('../models/product.model');
const { NotFoundError, ConflictError } = require('../utils/errors');
const { paginate } = require('../utils/response');

const ProductService = {
  async getAll({ page, limit, search, categoryId, supplierId, lowStock }) {
    const { pagination, offset, limit: perPage } = paginate(page, limit);
    const { rows, total } = await ProductModel.findAll({
      limit: perPage, offset, search, categoryId, supplierId,
      lowStock: lowStock === 'true',
    });
    return { products: rows, pagination: { ...pagination, total, totalPages: Math.ceil(total / perPage) } };
  },

  async getById(id) {
    const product = await ProductModel.findById(id);
    if (!product) throw new NotFoundError('Product not found');
    return product;
  },

  async create(data) {
    if (data.sku) {
      const existing = await ProductModel.findBySku(data.sku);
      if (existing) throw new ConflictError(`SKU '${data.sku}' already exists`);
    }
    return ProductModel.create(data);
  },

  async update(id, fields) {
    const exists = await ProductModel.findById(id);
    if (!exists) throw new NotFoundError('Product not found');
    if (fields.sku && fields.sku !== exists.sku) {
      const skuConflict = await ProductModel.findBySku(fields.sku);
      if (skuConflict) throw new ConflictError(`SKU '${fields.sku}' already exists`);
    }
    return ProductModel.update(id, fields);
  },

  async delete(id) {
    const exists = await ProductModel.findById(id);
    if (!exists) throw new NotFoundError('Product not found');
    await ProductModel.delete(id);
    return true;
  },

  async getLowStock() {
    return ProductModel.getLowStockProducts();
  },
};

module.exports = ProductService;
