const DashboardModel = require('../models/dashboard.model');

const DashboardService = {
  async getAnalytics({ days = 30 } = {}) {
    const [overview, stockMovement, topProducts, categoryBreakdown, recentTransactions, lowStockProducts] =
      await Promise.all([
        DashboardModel.getOverview(),
        DashboardModel.getStockMovement({ days }),
        DashboardModel.getTopProducts({ limit: 10 }),
        DashboardModel.getCategoryBreakdown(),
        DashboardModel.getRecentTransactions({ limit: 10 }),
        DashboardModel.getLowStockProducts({ limit: 20 }),
      ]);

    return {
      overview,
      stockMovement,
      topProducts,
      categoryBreakdown,
      recentTransactions,
      lowStockProducts,
    };
  },

  async getOverview() {
    return DashboardModel.getOverview();
  },

  async getStockMovement({ days }) {
    return DashboardModel.getStockMovement({ days });
  },
};

module.exports = DashboardService;
