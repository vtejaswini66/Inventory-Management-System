const CategoryModel = require('../models/category.model');
const { NotFoundError, ConflictError } = require('../utils/errors');
const { paginate } = require('../utils/response');

const CategoryService = {
  async getAll({ page, limit, search }) {
    const { pagination, offset, limit: perPage } = paginate(page, limit);
    const { rows, total } = await CategoryModel.findAll({ limit: perPage, offset, search });
    return { categories: rows, pagination: { ...pagination, total, totalPages: Math.ceil(total / perPage) } };
  },

  async getById(id) {
    const category = await CategoryModel.findById(id);
    if (!category) throw new NotFoundError('Category not found');
    return category;
  },

  async create({ name, description }) {
    const existing = await CategoryModel.findByName(name);
    if (existing) throw new ConflictError(`Category '${name}' already exists`);
    return CategoryModel.create({ name, description });
  },

  async update(id, fields) {
    const exists = await CategoryModel.findById(id);
    if (!exists) throw new NotFoundError('Category not found');
    if (fields.name && fields.name !== exists.name) {
      const nameConflict = await CategoryModel.findByName(fields.name);
      if (nameConflict) throw new ConflictError(`Category '${fields.name}' already exists`);
    }
    return CategoryModel.update(id, fields);
  },

  async delete(id) {
    const exists = await CategoryModel.findById(id);
    if (!exists) throw new NotFoundError('Category not found');
    await CategoryModel.delete(id);
    return true;
  },
};

module.exports = CategoryService;
