const { getClient } = require('../config/database');
const InventoryModel = require('../models/inventory.model');
const ProductModel = require('../models/product.model');
const { NotFoundError, ValidationError } = require('../utils/errors');
const { paginate } = require('../utils/response');

const InventoryService = {
  async stockIn({ productId, quantity, unitCost, reference, supplierId, notes, userId }) {
    if (quantity <= 0) throw new ValidationError('Quantity must be greater than 0');
    const client = await getClient();
    try {
      await client.query('BEGIN');
      const product = await ProductModel.findById(productId);
      if (!product) throw new NotFoundError('Product not found');

      const transaction = await InventoryModel.createTransaction(client, {
        productId, type: 'stock_in', quantity, unitCost, reference, supplierId, notes, createdBy: userId,
      });

      const updated = await ProductModel.updateQuantity(client, productId, quantity);
      await client.query('COMMIT');
      return { transaction, product: updated };
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },

  async stockOut({ productId, quantity, reference, notes, userId }) {
    if (quantity <= 0) throw new ValidationError('Quantity must be greater than 0');
    const client = await getClient();
    try {
      await client.query('BEGIN');
      const product = await ProductModel.findById(productId);
      if (!product) throw new NotFoundError('Product not found');
      if (product.quantity < quantity) {
        throw new ValidationError(`Insufficient stock. Available: ${product.quantity}, Requested: ${quantity}`);
      }

      const transaction = await InventoryModel.createTransaction(client, {
        productId, type: 'stock_out', quantity, reference, notes, createdBy: userId,
      });

      const updated = await ProductModel.updateQuantity(client, productId, -quantity);
      await client.query('COMMIT');
      return { transaction, product: updated };
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },

  async adjust({ productId, quantity, reference, notes, userId }) {
    // quantity can be positive or negative
    const client = await getClient();
    try {
      await client.query('BEGIN');
      const product = await ProductModel.findById(productId);
      if (!product) throw new NotFoundError('Product not found');
      if (product.quantity + quantity < 0) {
        throw new ValidationError(`Adjustment would result in negative stock. Current: ${product.quantity}`);
      }

      const transaction = await InventoryModel.createTransaction(client, {
        productId, type: 'adjustment', quantity, reference, notes, createdBy: userId,
      });

      const updated = await ProductModel.updateQuantity(client, productId, quantity);
      await client.query('COMMIT');
      return { transaction, product: updated };
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },

  async getTransactions({ page, limit, productId, type, startDate, endDate, search }) {
    const { pagination, offset, limit: perPage } = paginate(page, limit);
    const { rows, total } = await InventoryModel.findAll({
      limit: perPage, offset, productId, type, startDate, endDate, search,
    });
    return { transactions: rows, pagination: { ...pagination, total, totalPages: Math.ceil(total / perPage) } };
  },

  async getTransactionById(id) {
    const tx = await InventoryModel.findById(id);
    if (!tx) throw new NotFoundError('Transaction not found');
    return tx;
  },

  async getProductTransactionSummary(productId) {
    const product = await ProductModel.findById(productId);
    if (!product) throw new NotFoundError('Product not found');
    const summary = await InventoryModel.getSummaryByProduct(productId);
    return { product, summary };
  },
};

module.exports = InventoryService;
