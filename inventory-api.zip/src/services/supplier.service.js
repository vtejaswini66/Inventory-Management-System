const SupplierModel = require('../models/supplier.model');
const { NotFoundError, ConflictError } = require('../utils/errors');
const { paginate } = require('../utils/response');

const SupplierService = {
  async getAll({ page, limit, search, isActive }) {
    const { pagination, offset, limit: perPage } = paginate(page, limit);
    const active = isActive === 'true' ? true : isActive === 'false' ? false : undefined;
    const { rows, total } = await SupplierModel.findAll({ limit: perPage, offset, search, isActive: active });
    return { suppliers: rows, pagination: { ...pagination, total, totalPages: Math.ceil(total / perPage) } };
  },

  async getById(id) {
    const supplier = await SupplierModel.findById(id);
    if (!supplier) throw new NotFoundError('Supplier not found');
    return supplier;
  },

  async create(data) {
    if (data.email) {
      const existing = await SupplierModel.findByEmail(data.email);
      if (existing) throw new ConflictError(`Supplier with email '${data.email}' already exists`);
    }
    return SupplierModel.create(data);
  },

  async update(id, fields) {
    const exists = await SupplierModel.findById(id);
    if (!exists) throw new NotFoundError('Supplier not found');
    if (fields.email && fields.email !== exists.email) {
      const emailConflict = await SupplierModel.findByEmail(fields.email);
      if (emailConflict) throw new ConflictError(`Email '${fields.email}' already in use`);
    }
    return SupplierModel.update(id, fields);
  },

  async delete(id) {
    const exists = await SupplierModel.findById(id);
    if (!exists) throw new NotFoundError('Supplier not found');
    await SupplierModel.delete(id);
    return true;
  },
};

module.exports = SupplierService;
