const SupplierService = require('../services/supplier.service');
const { sendSuccess, sendCreated } = require('../utils/response');

const SupplierController = {
  async getAll(req, res, next) {
    try {
      const { page = 1, limit = 20, search, isActive } = req.query;
      const result = await SupplierService.getAll({ page, limit, search, isActive });
      sendSuccess(res, result, 'Suppliers retrieved');
    } catch (err) { next(err); }
  },

  async getById(req, res, next) {
    try {
      const supplier = await SupplierService.getById(req.params.id);
      sendSuccess(res, supplier, 'Supplier retrieved');
    } catch (err) { next(err); }
  },

  async create(req, res, next) {
    try {
      const { name, email, phone, contactPerson, address, notes } = req.body;
      const supplier = await SupplierService.create({ name, email, phone, contactPerson, address, notes });
      sendCreated(res, supplier, 'Supplier created');
    } catch (err) { next(err); }
  },

  async update(req, res, next) {
    try {
      const { name, email, phone, contactPerson, address, notes, isActive } = req.body;
      const supplier = await SupplierService.update(req.params.id, { name, email, phone, contactPerson, address, notes, isActive });
      sendSuccess(res, supplier, 'Supplier updated');
    } catch (err) { next(err); }
  },

  async delete(req, res, next) {
    try {
      await SupplierService.delete(req.params.id);
      sendSuccess(res, null, 'Supplier deleted');
    } catch (err) { next(err); }
  },
};

module.exports = SupplierController;
