const ProductService = require('../services/product.service');
const { sendSuccess, sendCreated } = require('../utils/response');

const ProductController = {
  async getAll(req, res, next) {
    try {
      const { page = 1, limit = 20, search, categoryId, supplierId, lowStock } = req.query;
      const result = await ProductService.getAll({ page, limit, search, categoryId, supplierId, lowStock });
      sendSuccess(res, result, 'Products retrieved');
    } catch (err) { next(err); }
  },

  async getById(req, res, next) {
    try {
      const product = await ProductService.getById(req.params.id);
      sendSuccess(res, product, 'Product retrieved');
    } catch (err) { next(err); }
  },

  async create(req, res, next) {
    try {
      const { name, sku, description, categoryId, supplierId, unitPrice, costPrice, quantity, reorderLevel, unit } = req.body;
      const product = await ProductService.create({ name, sku, description, categoryId, supplierId, unitPrice, costPrice, quantity, reorderLevel, unit });
      sendCreated(res, product, 'Product created');
    } catch (err) { next(err); }
  },

  async update(req, res, next) {
    try {
      const product = await ProductService.update(req.params.id, req.body);
      sendSuccess(res, product, 'Product updated');
    } catch (err) { next(err); }
  },

  async delete(req, res, next) {
    try {
      await ProductService.delete(req.params.id);
      sendSuccess(res, null, 'Product deleted');
    } catch (err) { next(err); }
  },

  async getLowStock(req, res, next) {
    try {
      const products = await ProductService.getLowStock();
      sendSuccess(res, products, 'Low stock products retrieved');
    } catch (err) { next(err); }
  },
};

module.exports = ProductController;
