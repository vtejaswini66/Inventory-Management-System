const CategoryService = require('../services/category.service');
const { sendSuccess, sendCreated, sendError } = require('../utils/response');

const CategoryController = {
  async getAll(req, res, next) {
    try {
      const { page = 1, limit = 20, search } = req.query;
      const result = await CategoryService.getAll({ page, limit, search });
      sendSuccess(res, result, 'Categories retrieved', 200, { pagination: result.pagination });
    } catch (err) { next(err); }
  },

  async getById(req, res, next) {
    try {
      const category = await CategoryService.getById(req.params.id);
      sendSuccess(res, category, 'Category retrieved');
    } catch (err) { next(err); }
  },

  async create(req, res, next) {
    try {
      const category = await CategoryService.create(req.body);
      sendCreated(res, category, 'Category created');
    } catch (err) { next(err); }
  },

  async update(req, res, next) {
    try {
      const category = await CategoryService.update(req.params.id, req.body);
      sendSuccess(res, category, 'Category updated');
    } catch (err) { next(err); }
  },

  async delete(req, res, next) {
    try {
      await CategoryService.delete(req.params.id);
      sendSuccess(res, null, 'Category deleted');
    } catch (err) { next(err); }
  },
};

module.exports = CategoryController;
