const InventoryService = require('../services/inventory.service');
const { sendSuccess, sendCreated } = require('../utils/response');

const InventoryController = {
  async stockIn(req, res, next) {
    try {
      const { productId, quantity, unitCost, reference, supplierId, notes } = req.body;
      const result = await InventoryService.stockIn({
        productId, quantity: parseInt(quantity, 10),
        unitCost: parseFloat(unitCost) || 0,
        reference, supplierId, notes, userId: req.user.id,
      });
      sendCreated(res, result, 'Stock in recorded successfully');
    } catch (err) { next(err); }
  },

  async stockOut(req, res, next) {
    try {
      const { productId, quantity, reference, notes } = req.body;
      const result = await InventoryService.stockOut({
        productId, quantity: parseInt(quantity, 10), reference, notes, userId: req.user.id,
      });
      sendCreated(res, result, 'Stock out recorded successfully');
    } catch (err) { next(err); }
  },

  async adjust(req, res, next) {
    try {
      const { productId, quantity, reference, notes } = req.body;
      const result = await InventoryService.adjust({
        productId, quantity: parseInt(quantity, 10), reference, notes, userId: req.user.id,
      });
      sendCreated(res, result, 'Inventory adjustment recorded');
    } catch (err) { next(err); }
  },

  async getTransactions(req, res, next) {
    try {
      const { page = 1, limit = 20, productId, type, startDate, endDate, search } = req.query;
      const result = await InventoryService.getTransactions({ page, limit, productId, type, startDate, endDate, search });
      sendSuccess(res, result, 'Transactions retrieved');
    } catch (err) { next(err); }
  },

  async getTransactionById(req, res, next) {
    try {
      const tx = await InventoryService.getTransactionById(req.params.id);
      sendSuccess(res, tx, 'Transaction retrieved');
    } catch (err) { next(err); }
  },

  async getProductSummary(req, res, next) {
    try {
      const result = await InventoryService.getProductTransactionSummary(req.params.productId);
      sendSuccess(res, result, 'Product transaction summary retrieved');
    } catch (err) { next(err); }
  },
};

module.exports = InventoryController;
