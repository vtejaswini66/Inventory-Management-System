const DashboardService = require('../services/dashboard.service');
const { sendSuccess } = require('../utils/response');

const DashboardController = {
  async getAnalytics(req, res, next) {
    try {
      const { days = 30 } = req.query;
      const data = await DashboardService.getAnalytics({ days: parseInt(days, 10) });
      sendSuccess(res, data, 'Dashboard analytics retrieved');
    } catch (err) { next(err); }
  },

  async getOverview(req, res, next) {
    try {
      const data = await DashboardService.getOverview();
      sendSuccess(res, data, 'Overview retrieved');
    } catch (err) { next(err); }
  },

  async getStockMovement(req, res, next) {
    try {
      const { days = 30 } = req.query;
      const data = await DashboardService.getStockMovement({ days: parseInt(days, 10) });
      sendSuccess(res, data, 'Stock movement retrieved');
    } catch (err) { next(err); }
  },
};

module.exports = DashboardController;
