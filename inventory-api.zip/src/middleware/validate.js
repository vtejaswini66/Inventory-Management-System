const { validationResult } = require('express-validator');
const { sendBadRequest } = require('../utils/response');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const formatted = errors.array().map((e) => ({
      field: e.path,
      message: e.msg,
      value: e.value,
    }));
    return sendBadRequest(res, 'Validation failed', formatted);
  }
  next();
};

module.exports = { validate };
