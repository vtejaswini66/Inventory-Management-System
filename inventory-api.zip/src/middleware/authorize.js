const { sendForbidden } = require('../utils/response');

const ROLES = {
  ADMIN: 'admin',
  MANAGER: 'manager',
  STAFF: 'staff',
};

const ROLE_HIERARCHY = {
  admin: 3,
  manager: 2,
  staff: 1,
};

/**
 * Authorize by exact role(s)
 * Usage: authorize('admin') or authorize(['admin', 'manager'])
 */
const authorize = (...roles) => {
  const allowedRoles = roles.flat();
  return (req, res, next) => {
    if (!req.user) return sendForbidden(res, 'Not authenticated');
    const userRole = req.user.role || 'staff';
    if (!allowedRoles.includes(userRole)) {
      return sendForbidden(res, `Requires role: ${allowedRoles.join(' or ')}`);
    }
    next();
  };
};

/**
 * Authorize by minimum role level
 * Usage: authorizeMin('manager') — allows manager and admin
 */
const authorizeMin = (minRole) => {
  return (req, res, next) => {
    if (!req.user) return sendForbidden(res, 'Not authenticated');
    const userLevel = ROLE_HIERARCHY[req.user.role] || 0;
    const requiredLevel = ROLE_HIERARCHY[minRole] || 0;
    if (userLevel < requiredLevel) {
      return sendForbidden(res, `Requires at least role: ${minRole}`);
    }
    next();
  };
};

/**
 * Admin-only shorthand
 */
const adminOnly = authorize(ROLES.ADMIN);

/**
 * Admin or manager shorthand
 */
const managerOrAbove = authorizeMin(ROLES.MANAGER);

module.exports = { authorize, authorizeMin, adminOnly, managerOrAbove, ROLES };
