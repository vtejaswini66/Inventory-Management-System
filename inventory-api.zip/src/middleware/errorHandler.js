const logger = require('../utils/logger');
const { AppError } = require('../utils/errors');

// 404 handler
const notFound = (req, res, next) => {
  const err = new AppError(`Route not found: ${req.method} ${req.originalUrl}`, 404);
  next(err);
};

// Central error handler
// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  let { statusCode = 500, message, errors } = err;

  // PostgreSQL unique constraint
  if (err.code === '23505') {
    statusCode = 409;
    message = 'Resource already exists';
    const match = err.detail?.match(/Key \((.+)\)=\((.+)\) already exists/);
    if (match) message = `${match[1]} '${match[2]}' already exists`;
  }

  // PostgreSQL foreign key violation
  if (err.code === '23503') {
    statusCode = 400;
    message = 'Referenced resource does not exist';
  }

  // PostgreSQL not null violation
  if (err.code === '23502') {
    statusCode = 400;
    message = `Column '${err.column}' cannot be null`;
  }

  // Express-validator errors
  if (err.type === 'entity.parse.failed') {
    statusCode = 400;
    message = 'Invalid JSON body';
  }

  // Log server errors only
  if (statusCode >= 500) {
    logger.error('Server error', {
      message: err.message,
      stack: err.stack,
      url: req.originalUrl,
      method: req.method,
      ip: req.ip,
    });
  } else {
    logger.warn('Client error', { statusCode, message, url: req.originalUrl });
  }

  const response = {
    success: false,
    message: statusCode >= 500 && process.env.NODE_ENV === 'production'
      ? 'Internal server error'
      : message,
  };

  if (errors) response.errors = errors;

  if (process.env.NODE_ENV !== 'production' && statusCode >= 500) {
    response.stack = err.stack;
  }

  res.status(statusCode).json(response);
};

module.exports = { notFound, errorHandler };
