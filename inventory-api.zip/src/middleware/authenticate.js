const { auth } = require('../config/auth');
const { sendUnauthorized, sendForbidden } = require('../utils/response');
const logger = require('../utils/logger');

/**
 * Verify session using Better Auth
 */
const authenticate = async (req, res, next) => {
  try {
    const session = await auth.api.getSession({
      headers: req.headers,
    });

    if (!session || !session.user) {
      return sendUnauthorized(res, 'Invalid or expired session');
    }

    if (!session.user.isActive && session.user.isActive !== undefined) {
      return sendForbidden(res, 'Account is deactivated');
    }

    req.user = session.user;
    req.session = session.session;
    next();
  } catch (err) {
    logger.error('Authentication error', { error: err.message });
    return sendUnauthorized(res, 'Authentication failed');
  }
};

/**
 * Optional auth — attaches user if session exists, but doesn't block
 */
const optionalAuth = async (req, res, next) => {
  try {
    const session = await auth.api.getSession({ headers: req.headers });
    if (session?.user) {
      req.user = session.user;
      req.session = session.session;
    }
  } catch (_) {
    // silent — not required
  }
  next();
};

module.exports = { authenticate, optionalAuth };
